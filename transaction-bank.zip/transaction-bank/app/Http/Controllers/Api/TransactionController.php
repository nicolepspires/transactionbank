<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Client;

class TransactionController extends Controller
{
    public function transfer($transferValue, Client $payerClient, Client $payeeClient){

        try {
            $clientPayer = ClientController::getClientFromId($payerClient->federalCode);

            $clientPayee = ClientController::getClientFromId($payeeClient->federalCode);

            $validBalance = TransactionController::toValidateBalance($clientPayer->balance, $transferValue);

            $validPayer = $this->isValidPayer($clientPayer->type);

            //TODO: Chamar Serviço autorizador

            if ($validBalance && $validPayer) {
                ClientController::toDebitFromClient($clientPayer, $transferValue);

                ClientController::toPayClient($clientPayee, $transferValue);

                //TODO: Notificar -> Em caso de erro, retentar

                return['return'=>'ok'];
            }
            return['return'=>'insufficient balance or customer not allowed to carry out trasaction'];

        }catch (\Exception $error){
            return['return'=>'error', 'details'=>$error];
        }
    }

    function toValidateBalance($balance, $transferValue){
        try {
            if ($balance == 0 || $transferValue > $balance) {
                return false;
            }
            return true;
        }catch (\Exception $error){
            return['return'=>'error', 'details'=>$error];
        }
    }

    function isValidPayer($type){
        try {
            if ($type == "shopkeeper") {
                return false;
            }
            return true;
        }catch (\Exception $error){
            return['return'=>'error', 'details'=>$error];
        }
    }
}
