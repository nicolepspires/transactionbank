<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class TransactionController extends Controller
{
    public function transfer(Request $request){

        try {

            $clientPayer = Client::find($request->payerFederalCode);

            $clientPayee = Client::find($request->payeeFederalCode);

            $validBalance = $this::isValidBalance($clientPayer->balance, $request->transferValue);

            $validPayer = $this::isValidPayer($clientPayer->type);

            $responseAuthorization = $this::isAuthorized();

            if ($validBalance && $validPayer && $responseAuthorization) {
                $this::toDebitFromClient($clientPayer, $request->transferValue);

                $this::toPayClient($clientPayee, $request->transferValue, $clientPayer);

                $this::notifySucess();

                return['transferStatus'=>'ok'];
            }

            return['return'=>'insufficient balance or customer not allowed to carry out trasaction'];

        }catch (\Exception $error){
            return['return'=>'error', 'details'=>$error];
        }
    }

    function isValidBalance($balance, $transferValue){
        try {
            if ($balance == 0 || $transferValue > $balance) {
                return false;
            }
            return true;
        }catch (\Exception $error){
            return['return'=>'error', 'details'=>$error];
        }
    }

    function isValidPayer($type){
        try {
            if ((strcmp($type,"common")) == 0) {
                return true;
            }
            return false;
        }catch (\Exception $error){
            return['return'=>'error', 'details'=>$error];
        }
    }

    public function isAuthorized(){
        try {
            $response = Http::get("https://run.mocky.io/v3/8fafdd68-a090-496f-8c9a-3442cf30dae6");
            if((strcmp($response->message,"Autorizado")) == 0){
                return true;
            }
            return false;
        }catch (\Exception $error){
            return ['return'=>'Authorize error', 'details'=>$error];
        }
    }

    public function toDebitFromClient(Client $client, $transferValue){

        try {

            $newBalance = $client->balance - $transferValue;

            $client->balance = $newBalance;

            $client->save();

        }catch (\Exception $error){
            return ['return'=>'error to process debit', 'details'=>$error];
        }
    }

    public function toPayClient(Client $clientPayee, $transferValue, Client $clientPayer){

        try {

            $newBalance = $clientPayee->balance + $transferValue;

            $clientPayee->balance = $newBalance;

            $clientPayee->save();

        }catch (\Exception $error){
            $this::undoTransfer($clientPayer, $transferValue);
            return ['return'=>'error to process debit', 'details'=>$error];
        }
    }

    public function undoTransfer(Client $clientPayer, $transferValue){

        try {

            $newBalance = $clientPayer->balance + $transferValue;

            $clientPayer->balance = $newBalance;

            $clientPayer->save();

        }catch (\Exception $error){
            return ['return'=>'error to process debit', 'details'=>$error];
        }
    }

    public function notifySucess(){
        try {
            Http::retry(3, 100)->get("http://o4d9z.mocklab.io/notify");
        }catch (\Exception $error){
            return ['return'=>'Notification error', 'details'=>$error];
        }
    }
}
