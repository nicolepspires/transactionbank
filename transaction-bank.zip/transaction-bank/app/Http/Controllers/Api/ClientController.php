<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Client;
use Illuminate\Http\Request;

class ClientController extends Controller

{
    public function insertClient(Client $client, Request $request){
        try {

            $firstBalance = 0.0;

            $client->id = $request->federalCode;
            $client->fullName = $request->fullName;
            $client->email = $request->email;
            $client->federalCode = $request->federalCode;
            $client->type = $request->clientType;
            $client->balance = $firstBalance;
            $client->save();

            return['return'=>'Ok, '.$request->fullName.' is a new client.'];

        }catch (\Exception $error){
            return ['return'=>'error to process client insert', 'details'=>$error];
        }
    }

    public function getClients(){

        try {
            $client = Client::all();

            return $client;
        }catch (\Exception $error){
            return ['return'=>'error to process client fetching balance', 'details'=>$error];
        }
    }

    public function getClientFromId($id){

        try {
            $client = Client::find($id);

            return $client;
        }catch (\Exception $error){
            return ['return'=>'error to process client fetching balance', 'details'=>$error];
        }
    }

    public function toDebitFromClient(Client $client, $transferValue){

        try {

            $newBalance = $client->balance - $transferValue;

            $client->balance = $newBalance;

            $client->save();

        }catch (\Exception $error){
            return ['return'=>'error to process debit', 'details'=>$error];
        }
    }

    public function toPayClient(Client $client, $transferValue){

        try {

            $newBalance = $client->balance + $transferValue;

            $client->balance = $newBalance;

            $client->save();

        }catch (\Exception $error){
            return ['return'=>'error to process debit', 'details'=>$error];
        }
    }
}
