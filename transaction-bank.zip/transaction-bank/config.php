<?php

    //Mysql
    const DBDRIVE = 'mysql';
    const DBHOST = 'localhost';
    const DBNAME = 'transaction';
    const DBUSER = 'transaction';
    const DBPASS = '';

